package com.elean.ecrop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcropApplicationTests {

	@Test
	void contextLoads() {
	}

}
