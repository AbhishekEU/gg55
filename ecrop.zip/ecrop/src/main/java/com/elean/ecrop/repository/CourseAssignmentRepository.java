package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.CourseAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CourseAssignmentRepository extends JpaRepository<CourseAssignment, Long> {

    List<CourseAssignment> findByManagerId(Long managerId);

    List<CourseAssignment> findByEmployeeId(Long employeeId);
}
