package com.elean.ecrop.pojo;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "course_assignments")
public class CourseAssignment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long managerId;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private Long employeeId; // For individual assignments; extend with teamId if needed

    private LocalDate deadline;

    public CourseAssignment() {}

    public CourseAssignment(Long managerId, Course course, Long employeeId, LocalDate deadline) {
        this.managerId = managerId;
        this.course = course;
        this.employeeId = employeeId;
        this.deadline = deadline;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getManagerId() { return managerId; }
    public void setManagerId(Long managerId) { this.managerId = managerId; }

    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }

    public Long getEmployeeId() { return employeeId; }
    public void setEmployeeId(Long employeeId) { this.employeeId = employeeId; }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    @Override
    public String toString() {
        return "CourseAssignment{" +
                "id=" + id +
                ", managerId=" + managerId +
                ", course=" + (course != null ? course.getId() : null) +
                ", employeeId=" + employeeId +
                ", deadline=" + deadline +
                '}';
    }
}
