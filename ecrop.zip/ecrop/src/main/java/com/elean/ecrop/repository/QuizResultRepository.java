package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.QuizResult;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface QuizResultRepository extends JpaRepository<QuizResult, Integer> {
    List<QuizResult> findByQuizCourseId(int courseId);
    List<QuizResult> findByQuizId(int quizId);
    List<QuizResult> findByEmployeeNameIgnoreCase(String employeeName);
}
