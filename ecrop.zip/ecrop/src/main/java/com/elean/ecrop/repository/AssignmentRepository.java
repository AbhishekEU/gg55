package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AssignmentRepository extends JpaRepository<Assignment, Integer> {
    List<Assignment> findByCourseId(int courseId);
}
