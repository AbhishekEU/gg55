package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Integer> {
    List<Enrollment> findByEmployeeId(Integer employeeId);

    @Transactional
    void deleteByCourseId(Integer courseId);
}
