package com.elean.ecrop.repository;

public class StudentRepo {

}
