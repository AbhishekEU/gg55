package com.elean.ecrop.pojo;

import jakarta.persistence.*;

@Entity
@Table(name = "enrollments")
public class Enrollment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "employee_id", insertable=false, updatable=false)
    private Integer employeeId;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;  // Add this relation to get Employee info

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private int progress;       // Progress in percentage
    private boolean completed;  // true if finished

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getEmployeeId() { return employeeId; }
    public void setEmployeeId(Integer employeeId) { this.employeeId = employeeId; }

    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }

    public int getProgress() { return progress; }
    public void setProgress(int progress) { this.progress = progress; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
}
