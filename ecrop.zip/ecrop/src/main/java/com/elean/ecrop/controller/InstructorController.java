package com.elean.ecrop.controller;

import com.elean.ecrop.pojo.*;
import com.elean.ecrop.repository.*;
import com.elean.ecrop.service.InstructorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * InstructorController allows instructors to manage courses, quizzes,
 * materials, progress, feedback, forums, webinars, and quiz scores.
 */
@RestController
@RequestMapping("/instructor")
@CrossOrigin(origins = "http://localhost:4200/")
public class InstructorController {

    @Autowired
    private InstructorService instructorService;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private ForumRepository forumRepository;

    @Autowired
    private WebinarRepository webinarRepository;

    @Autowired
    private CourseMaterialRepository courseMaterialRepository;

    // =========================================================================
    // COURSE MANAGEMENT
    // =========================================================================

    @PostMapping("/courses")
    public ResponseEntity<?> createCourse(@RequestBody Course course) {
        instructorService.createCourse(course);
        return ResponseEntity.ok(Collections.singletonMap("message", "Course created successfully."));
    }

    @PutMapping("/courses/{id}")
    public ResponseEntity<?> updateCourse(@PathVariable int id, @RequestBody Course updated) {
        return instructorService.updateCourse(id, updated)
                .map(c -> ResponseEntity.ok(Collections.singletonMap("message", "Course updated successfully.")))
                .orElse(ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found.")));
    }

    @DeleteMapping("/courses/{id}")
    public ResponseEntity<?> deleteCourse(@PathVariable int id) {
        boolean deleted = instructorService.deleteCourse(id);
        if (deleted) {
            return ResponseEntity.ok(Collections.singletonMap("message", "Course deleted successfully."));
        }
        return ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found."));
    }

    @GetMapping("/courses/{id}")
    public ResponseEntity<?> getCourse(@PathVariable int id) {
        Optional<Course> courseOpt = courseRepository.findById(id);
        if (courseOpt.isPresent()) {
            return ResponseEntity.ok(courseOpt.get());
        } else {
            return ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found."));
        }
    }

    // =========================================================================
    // QUIZ MANAGEMENT
    // =========================================================================

    @PostMapping("/courses/{courseId}/quizzes")
    public ResponseEntity<?> createQuiz(@PathVariable int courseId, @RequestBody Quiz quiz) {
        return instructorService.addQuizToCourse(courseId, quiz)
                .map(q -> ResponseEntity.ok(Collections.singletonMap("message", "Quiz created successfully.")))
                .orElse(ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found.")));
    }

    // =========================================================================
    // MATERIAL UPLOAD
    // =========================================================================

    @PostMapping("/courses/{courseId}/materials")
    public ResponseEntity<?> uploadMaterial(@PathVariable int courseId, @RequestBody CourseMaterial material) {
        return courseRepository.findById(courseId)
                .map(course -> {
                    material.setCourse(course);
                    courseMaterialRepository.save(material);
                    return ResponseEntity.ok(Collections.singletonMap("message", "Material uploaded successfully."));
                })
                .orElse(ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found.")));
    }

    // =========================================================================
    // PROGRESS MONITORING
    // =========================================================================

    @GetMapping("/courses/{id}/progress")
    public ResponseEntity<?> monitorProgress(@PathVariable int id) {
        return courseRepository.findById(id)
                .map(course -> {
                    List<Assignment> assignments = assignmentRepository.findByCourseId(id);
                    List<Quiz> quizzes = quizRepository.findByCourseId(id);
                    Map<String, Object> result = new HashMap<>();
                    result.put("course", course);
                    result.put("assignments", assignments);
                    result.put("quizzes", quizzes);
                    return ResponseEntity.ok(result);
                })
                .orElse(ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found.")));
    }

    // =========================================================================
    // FEEDBACK
    // =========================================================================

    @PostMapping("/courses/{courseId}/feedback")
    public ResponseEntity<?> provideFeedback(@PathVariable int courseId, @RequestBody Map<String, String> body) {
        return courseRepository.findById(courseId)
                .map(course -> {
                    String feedback = body.get("feedback");
                    // Simulate saving feedback; you can extend this to persist
                    return ResponseEntity.ok(Collections.singletonMap("message", "Feedback recorded: " + feedback));
                })
                .orElse(ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found.")));
    }

    // =========================================================================
    // QUIZ SCORES
    // =========================================================================

    @PostMapping("/quizzes/{quizId}/submit-score")
    public ResponseEntity<?> submitQuizScore(@PathVariable int quizId, @RequestBody Map<String, Object> request) {
        String employeeName = (String) request.get("employeeName");
        int score = (int) request.get("score");

        try {
            QuizResult result = instructorService.submitQuizResult(quizId, employeeName, score);
            return ResponseEntity.ok(result);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(Collections.singletonMap("message", e.getMessage()));
        }
    }

    @GetMapping("/courses/{courseId}/quiz-results")
    public ResponseEntity<?> getQuizResultsForCourse(@PathVariable int courseId) {
        List<QuizResult> results = instructorService.getQuizResultsForCourse(courseId);
        return ResponseEntity.ok(results);
    }

    @GetMapping("/quiz-results/employee/{employeeName}")
    public ResponseEntity<?> getQuizResultsForEmployee(@PathVariable String employeeName) {
        List<QuizResult> results = instructorService.getQuizResultsForEmployee(employeeName);
        return ResponseEntity.ok(results);
    }

    // =========================================================================
    // FORUM INTERACTIONS
    // =========================================================================

    @PostMapping("/forums")
    public ResponseEntity<?> postForumMessage(@RequestBody Forum forum) {
        forumRepository.save(forum);
        return ResponseEntity.ok(Collections.singletonMap("message", "Forum post created successfully."));
    }

    @GetMapping("/forums")
    public ResponseEntity<?> listForumMessages() {
        List<Forum> forums = forumRepository.findAll();
        if (forums.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No forum posts available."));
        }
        return ResponseEntity.ok(forums);
    }

    // =========================================================================
    // WEBINARS
    // =========================================================================

    @PostMapping("/webinars")
    public ResponseEntity<?> scheduleWebinar(@RequestBody Webinar webinar) {
        webinarRepository.save(webinar);
        return ResponseEntity.ok(Collections.singletonMap("message", "Webinar scheduled successfully."));
    }

    @GetMapping("/webinars")
    public ResponseEntity<?> listWebinars() {
        List<Webinar> webinars = webinarRepository.findAll();
        if (webinars.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No webinars available."));
        }
        return ResponseEntity.ok(webinars);
    }
}
