package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.CourseMaterial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

public interface CourseMaterialRepository extends JpaRepository<CourseMaterial, Integer> {

    @Transactional
    void deleteByCourseId(int courseId);
}
