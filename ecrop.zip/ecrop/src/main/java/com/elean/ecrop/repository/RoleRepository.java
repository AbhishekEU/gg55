package com.elean.ecrop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.elean.ecrop.pojo.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {
}
