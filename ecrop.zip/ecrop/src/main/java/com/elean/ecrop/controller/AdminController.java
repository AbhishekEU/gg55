package com.elean.ecrop.controller;

import com.elean.ecrop.pojo.*;
import com.elean.ecrop.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "http://localhost:4200/")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PlatformConfigRepository configRepository;

    @Autowired
    private SupportRequestRepository supportRequestRepository;

    // -----------------------------------------------------------------------------------
    // USER & ROLE MANAGEMENT
    // -----------------------------------------------------------------------------------

    /**
     * Get all users in the system.
     * Useful for Admin to see all accounts.
     */
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Get a user by ID.
     * Helps Admin fetch specific user details.
     */
    @GetMapping("/users/{id}")
    public Optional<User> getUserById(@PathVariable int id) {
        return userRepository.findById(id);
    }

    /**
     * Add or update a user.
     * Allows Admin to create new accounts or update existing ones.
     */
    @PostMapping("/users")
    public ResponseEntity<?> addOrUpdateUser(@RequestBody User user) {
        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "User saved/updated successfully."));
    }

    /**
     * Delete a user by ID.
     * Allows Admin to remove accounts.
     */
    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable int id) {
        userRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "User deleted successfully."));
    }

    /**
     * Get all roles.
     * Allows Admin to see all available roles for assignment.
     */
    @GetMapping("/roles")
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }

    /**
     * Add or update a role.
     * Useful for creating or modifying roles dynamically.
     */
    @PostMapping("/roles")
    public ResponseEntity<?> addOrUpdateRole(@RequestBody Role role) {
        roleRepository.save(role);
        return ResponseEntity.ok(Map.of("message", "Role saved/updated successfully."));
    }

    /**
     * Delete a role by ID.
     */
    @DeleteMapping("/roles/{id}")
    public ResponseEntity<?> deleteRole(@PathVariable int id) {
        roleRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Role deleted successfully."));
    }

    // -----------------------------------------------------------------------------------
    // PLATFORM CONFIGURATION
    // -----------------------------------------------------------------------------------

    /**
     * Get all platform configurations.
     * Useful to see system-level settings like allowed file size, course visibility, etc.
     */
    @GetMapping("/configs")
    public List<PlatformConfig> getAllConfigs() {
        return configRepository.findAll();
    }

    /**
     * Add or update a platform configuration.
     * Lets Admin modify settings dynamically.
     */
    @PostMapping("/configs")
    public ResponseEntity<?> addOrUpdateConfig(@RequestBody PlatformConfig config) {
        configRepository.save(config);
        return ResponseEntity.ok(Map.of("message", "Configuration saved/updated successfully."));
    }

    /**
     * Delete a platform configuration by ID.
     */
    @DeleteMapping("/configs/{id}")
    public ResponseEntity<?> deleteConfig(@PathVariable int id) {
        configRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Configuration deleted successfully."));
    }

    // -----------------------------------------------------------------------------------
    // SUPPORT MANAGEMENT
    // -----------------------------------------------------------------------------------

    /**
     * Get all support requests.
     * Admin can review all pending, resolved, or new support tickets.
     */
    @GetMapping("/supports")
    public List<SupportRequest> getAllSupportRequests() {
        return supportRequestRepository.findAll();
    }

    /**
     * Update support request status or admin response.
     * Admin can mark support tickets as resolved, pending, etc.
     */
    @PutMapping("/supports/{id}")
    public ResponseEntity<?> updateSupportRequest(
            @PathVariable int id,
            @RequestBody SupportRequest updatedRequest) {

        Optional<SupportRequest> existingRequest = supportRequestRepository.findById(id);

        if (existingRequest.isPresent()) {
            SupportRequest req = existingRequest.get();
            req.setStatus(updatedRequest.getStatus());
            req.setAdminResponse(updatedRequest.getAdminResponse());
            supportRequestRepository.save(req);
            return ResponseEntity.ok(Map.of("message", "Support request updated successfully."));
        } else {
            return ResponseEntity.status(404).body(Map.of("message", "Support request not found."));
        }
    }

    /**
     * Delete a support request by ID.
     */
    @DeleteMapping("/supports/{id}")
    public ResponseEntity<?> deleteSupportRequest(@PathVariable int id) {
        supportRequestRepository.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "Support request deleted successfully."));
    }
}
