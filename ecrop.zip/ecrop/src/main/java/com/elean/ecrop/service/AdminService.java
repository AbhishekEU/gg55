package com.elean.ecrop.service;

import com.elean.ecrop.pojo.*;
import com.elean.ecrop.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired private UserRepository userRepo;
    @Autowired private RoleRepository roleRepo;
    @Autowired private PlatformConfigRepository configRepo;
    @Autowired private SupportRequestRepository supportRepo;

    // User & Role Management
    public List<User> getAllUsers() { return userRepo.findAll(); }
    public Optional<User> getUserById(int id) { return userRepo.findById(id); }
    public User saveUser(User user) { return userRepo.save(user); }
    public void deleteUser(int id) { userRepo.deleteById(id); }

    public List<Role> getAllRoles() { return roleRepo.findAll(); }
    public Role saveRole(Role role) { return roleRepo.save(role); }

    // Platform Configuration
    public List<PlatformConfig> getAllConfigs() { return configRepo.findAll(); }
    public PlatformConfig saveConfig(PlatformConfig config) { return configRepo.save(config); }

    // Support Management
    public List<SupportRequest> getAllSupportRequests() { return supportRepo.findAll(); }
    public SupportRequest updateSupportRequestStatus(int id, SupportRequest.Status status) {
        SupportRequest req = supportRepo.findById(id).orElseThrow(() -> new RuntimeException("Support Request not found"));
        req.setStatus(status);
        return supportRepo.save(req);
    }
}
