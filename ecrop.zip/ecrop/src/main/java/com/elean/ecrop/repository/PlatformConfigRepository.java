package com.elean.ecrop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.elean.ecrop.pojo.PlatformConfig;

public interface PlatformConfigRepository extends JpaRepository<PlatformConfig, Integer> {
}
