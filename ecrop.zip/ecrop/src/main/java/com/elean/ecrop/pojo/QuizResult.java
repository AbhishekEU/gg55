package com.elean.ecrop.pojo;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "quiz_results")
public class QuizResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "quiz_id")
    private Quiz quiz;

    @Column(nullable = false)
    private String employeeName;  // assuming simple string instead of separate Employee entity

    @Column(nullable = false)
    private int score;

    @Temporal(TemporalType.TIMESTAMP)
    private Date submittedAt = new Date();

    // Getters and Setters

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Quiz getQuiz() { return quiz; }
    public void setQuiz(Quiz quiz) { this.quiz = quiz; }

    public String getEmployeeName() { return employeeName; }
    public void setEmployeeName(String employeeName) { this.employeeName = employeeName; }

    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }

    public Date getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(Date submittedAt) { this.submittedAt = submittedAt; }
}
