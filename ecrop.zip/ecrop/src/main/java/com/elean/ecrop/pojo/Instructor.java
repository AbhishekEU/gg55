package com.elean.ecrop.pojo;

public class Instructor {

}
