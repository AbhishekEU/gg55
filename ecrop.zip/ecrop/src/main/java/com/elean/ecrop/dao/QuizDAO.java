package com.elean.ecrop.dao;

public class QuizDAO {

}
