package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.Webinar;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WebinarRepository extends JpaRepository<Webinar, Integer> {}
