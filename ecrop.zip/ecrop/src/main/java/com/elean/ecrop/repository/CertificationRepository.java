package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.Certification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CertificationRepository extends JpaRepository<Certification, Integer> {
    List<Certification> findByEmployeeId(int employeeId);

    @Transactional
    void deleteByCourseId(int courseId); // 💥 this deletes certifications for the course
}
