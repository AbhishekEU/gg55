package com.elean.ecrop.config;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@org.springframework.context.annotation.Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())  // disable CSRF
            .authorizeHttpRequests(auth -> auth
                .anyRequest().permitAll() // allow all endpoints
            )
            .formLogin(form -> form.disable()) // disable form login
            .httpBasic(basic -> basic.disable()); // disable HTTP Basic Auth

        return http.build();
    }
}
