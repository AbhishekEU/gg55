package com.elean.ecrop.service;

import com.elean.ecrop.pojo.*;
import com.elean.ecrop.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;

@Service
public class ManagerService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private CourseAssignmentRepository assignmentRepository;

    @Autowired
    private QuizResultRepository quizResultRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    /**
     * Assign a course to an employee with a deadline.
     */
    public CourseAssignment assignCourse(Long managerId, Integer courseId, Long employeeId, LocalDate deadline) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found."));
        CourseAssignment assignment = new CourseAssignment(managerId, course, employeeId, deadline);
        return assignmentRepository.save(assignment);
    }

    /**
     * Monitor progress: fetch enrollments and quiz scores for an employee.
     */
    public Map<String, Object> monitorEmployeeProgress(Integer employeeId) {
        List<Enrollment> enrollments = enrollmentRepository.findByEmployeeId(employeeId);

        if (enrollments.isEmpty()) {
            throw new RuntimeException("No enrollments found for employee ID: " + employeeId);
        }

        // Fetch employee name from the first enrollment's Employee object
        String employeeName = enrollments.get(0).getEmployee().getName();
        List<QuizResult> quizResults = quizResultRepository.findByEmployeeNameIgnoreCase(employeeName);

        Map<String, Object> progress = new HashMap<>();
        progress.put("enrollments", enrollments);
        progress.put("quizResults", quizResults);
        return progress;
    }

    /**
     * Generate reports: fetch all course assignments made by a manager.
     */
    public List<CourseAssignment> getAssignmentsByManager(Long managerId) {
        return assignmentRepository.findByManagerId(managerId);
    }
}
