package com.elean.ecrop.controller;

import com.elean.ecrop.pojo.Course;
import com.elean.ecrop.pojo.Enrollment;
import com.elean.ecrop.repository.CourseRepository;
import com.elean.ecrop.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * EmployeeController allows employees to browse courses,
 * enroll, track progress, and receive certifications.
 */
@RestController
@RequestMapping("/employee")
@CrossOrigin(origins = "http://localhost:4200/")
public class EmployeeController {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    // ============================================================================
    // COURSE BROWSING
    // ============================================================================

    /**
     * List all available courses.
     */
    @GetMapping("/courses")
    public ResponseEntity<?> getAllCourses() {
        List<Course> courses = courseRepository.findAll();
        if (courses.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No courses available."));
        }
        return ResponseEntity.ok(courses);
    }

    /**
     * Search courses by category.
     */
    @GetMapping("/courses/category/{category}")
    public ResponseEntity<?> searchCoursesByCategory(@PathVariable String category) {
        List<Course> filtered = courseRepository.findByCategoryIgnoreCase(category);
        if (filtered.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No courses found in category: " + category));
        }
        return ResponseEntity.ok(filtered);
    }

    /**
     * Search courses by level.
     */
    @GetMapping("/courses/level/{level}")
    public ResponseEntity<?> searchCoursesByLevel(@PathVariable String level) {
        List<Course> filtered = courseRepository.findByLevelIgnoreCase(level);
        if (filtered.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No courses found for level: " + level));
        }
        return ResponseEntity.ok(filtered);
    }

    /**
     * Search courses by instructor name.
     */
    @GetMapping("/courses/instructor/{instructor}")
    public ResponseEntity<?> searchCoursesByInstructor(@PathVariable String instructor) {
        List<Course> filtered = courseRepository.findByInstructorIgnoreCase(instructor);
        if (filtered.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No courses found for instructor: " + instructor));
        }
        return ResponseEntity.ok(filtered);
    }

    /**
     * View course details by ID.
     */
    @GetMapping("/courses/{id}")
    public ResponseEntity<?> getCourseDetails(@PathVariable int id) {
        Optional<Course> course = courseRepository.findById(id);
        return course.<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(Collections.singletonMap("message", "Course not found.")));
    }

    // ============================================================================
    // ENROLLMENT
    // ============================================================================

    /**
     * Enroll an employee in a course.
     */
    @PostMapping("/enrollments")
    public ResponseEntity<?> enroll(@RequestBody Enrollment enrollment) {
        enrollmentRepository.save(enrollment);
        return ResponseEntity.ok(Collections.singletonMap("message", "Enrollment successful."));
    }

    /**
     * Update progress of an enrollment.
     */
    @PutMapping("/enrollments/{id}")
    public ResponseEntity<?> updateProgress(@PathVariable int id, @RequestBody Enrollment updated) {
        Optional<Enrollment> enrollmentOpt = enrollmentRepository.findById(id);

        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            enrollment.setProgress(updated.getProgress());
            enrollment.setCompleted(updated.isCompleted());
            enrollmentRepository.save(enrollment);
            return ResponseEntity.ok(Collections.singletonMap("message", "Progress updated successfully."));
        } else {
            return ResponseEntity.status(404).body(Collections.singletonMap("message", "Enrollment not found."));
        }
    }

    /**
     * Get employee's enrollments with progress info.
     */
    @GetMapping("/enrollments/employee/{employeeId}")
    public ResponseEntity<?> getEmployeeEnrollments(@PathVariable int employeeId) {
        List<Enrollment> enrollments = enrollmentRepository.findByEmployeeId(employeeId);
        if (enrollments.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonMap("message", "No enrollments found for employee ID: " + employeeId));
        }
        return ResponseEntity.ok(enrollments);
    }

    /**
     * Generate a certificate upon course completion.
     */
    @GetMapping("/enrollments/{id}/certificate")
    public ResponseEntity<?> generateCertificate(@PathVariable int id) {
        Optional<Enrollment> enrollmentOpt = enrollmentRepository.findById(id);

        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            if (enrollment.isCompleted()) {
                Map<String, String> cert = new HashMap<>();
                cert.put("certificate", "Congratulations! You've completed the course: " + enrollment.getCourse().getName());
                cert.put("employee", "Employee ID: " + enrollment.getEmployeeId());
                cert.put("date", new Date().toString());
                return ResponseEntity.ok(cert);
            } else {
                return ResponseEntity.ok(Collections.singletonMap("message", "Course not yet completed."));
            }
        } else {
            return ResponseEntity.status(404).body(Collections.singletonMap("message", "Enrollment not found."));
        }
    }
}
