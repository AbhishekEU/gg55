package com.elean.ecrop.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.elean.ecrop.pojo.SupportRequest;

public interface SupportRequestRepository extends JpaRepository<SupportRequest, Integer> {
}
