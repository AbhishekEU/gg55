package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.Progress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ProgressRepository extends JpaRepository<Progress, Integer> {

    // Existing method: get progress entries for an employee
    List<Progress> findByEmployeeId(int employeeId);

    // NEW method: delete all progress records for a course before deleting the course itself
    @Transactional
    void deleteByCourseId(int courseId);
}
