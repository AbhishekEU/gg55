package com.elean.ecrop.pojo;

import jakarta.persistence.*;

@Entity
@Table(name = "support_requests")
public class SupportRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String email;

    private String subject;

    @Column(length = 2000)
    private String description;

    @Column(length = 2000)
    private String adminResponse; // Added field: admin reply to the request

    @Enumerated(EnumType.STRING)
    private Status status;

    public enum Status {
        NEW, IN_PROGRESS, RESOLVED
    }

    // --- Getters & Setters ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getAdminResponse() { return adminResponse; }
    public void setAdminResponse(String adminResponse) { this.adminResponse = adminResponse; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
}
