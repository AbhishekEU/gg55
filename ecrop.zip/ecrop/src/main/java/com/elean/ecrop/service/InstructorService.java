package com.elean.ecrop.service;

import com.elean.ecrop.pojo.*;
import com.elean.ecrop.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class InstructorService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private QuizRepository quizRepository;

    @Autowired
    private AssignmentRepository assignmentRepository;

    @Autowired
    private CertificationRepository certificationRepository;

    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private ProgressRepository progressRepository;

    @Autowired
    private CourseMaterialRepository courseMaterialRepository;

    @Autowired
    private QuizResultRepository quizResultRepository;

    // ------------------------------
    // COURSE METHODS
    // ------------------------------

    public Course createCourse(Course course) {
        return courseRepository.save(course);
    }

    public Optional<Course> updateCourse(int id, Course updated) {
        return courseRepository.findById(id).map(course -> {
            course.setName(updated.getName());
            course.setDescription(updated.getDescription());
            course.setCategory(updated.getCategory());
            course.setLevel(updated.getLevel());
            course.setInstructor(updated.getInstructor());
            return courseRepository.save(course);
        });
    }

    @Transactional
    public boolean deleteCourse(int courseId) {
        return courseRepository.findById(courseId).map(course -> {
            certificationRepository.deleteByCourseId(courseId);
            enrollmentRepository.deleteByCourseId(courseId);
            progressRepository.deleteByCourseId(courseId);
            quizRepository.deleteAll(quizRepository.findByCourseId(courseId));
            assignmentRepository.deleteAll(assignmentRepository.findByCourseId(courseId));
            courseMaterialRepository.deleteByCourseId(courseId);
            quizResultRepository.deleteAll(quizResultRepository.findByQuizCourseId(courseId));
            courseRepository.delete(course);
            return true;
        }).orElse(false);
    }

    // ------------------------------
    // QUIZ METHODS
    // ------------------------------

    public Optional<Quiz> addQuizToCourse(int courseId, Quiz quiz) {
        return courseRepository.findById(courseId).map(course -> {
            quiz.setCourse(course);
            return quizRepository.save(quiz);
        });
    }

    public List<Quiz> getQuizzesForCourse(int courseId) {
        return quizRepository.findByCourseId(courseId);
    }

    // ------------------------------
    // ASSIGNMENT METHODS
    // ------------------------------

    public Optional<Assignment> addAssignmentToCourse(int courseId, Assignment assignment) {
        return courseRepository.findById(courseId).map(course -> {
            assignment.setCourse(course);
            return assignmentRepository.save(assignment);
        });
    }

    public List<Assignment> getAssignmentsForCourse(int courseId) {
        return assignmentRepository.findByCourseId(courseId);
    }

    // ------------------------------
    // QUIZ RESULT METHODS
    // ------------------------------

    /**
     * Records a quiz result for an employee.
     */
    public QuizResult submitQuizResult(int quizId, String employeeName, int score) {
        return quizRepository.findById(quizId).map(quiz -> {
            QuizResult result = new QuizResult();
            result.setQuiz(quiz);
            result.setEmployeeName(employeeName);
            result.setScore(score);
            result.setSubmittedAt(new Date());
            return quizResultRepository.save(result);
        }).orElseThrow(() -> new RuntimeException("Quiz not found"));
    }

    /**
     * Returns all quiz results for a given course.
     */
    public List<QuizResult> getQuizResultsForCourse(int courseId) {
        return quizResultRepository.findByQuizCourseId(courseId);
    }

    /**
     * Returns all quiz results for a specific employee across all courses/quizzes.
     */
    public List<QuizResult> getQuizResultsForEmployee(String employeeName) {
        return quizResultRepository.findByEmployeeNameIgnoreCase(employeeName);
    }
}
