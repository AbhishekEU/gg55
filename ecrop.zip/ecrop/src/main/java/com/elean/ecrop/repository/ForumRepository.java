package com.elean.ecrop.repository;

import com.elean.ecrop.pojo.Forum;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ForumRepository extends JpaRepository<Forum, Integer> {}
