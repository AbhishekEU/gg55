package com.elean.ecrop.controller;

import com.elean.ecrop.pojo.CourseAssignment;
import com.elean.ecrop.service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/manager")
@CrossOrigin(origins = "http://localhost:4200/")
public class ManagerController {

    @Autowired
    private ManagerService managerService;

    /**
     * Assign a course to an employee.
     */
    @PostMapping("/assign-course")
    public ResponseEntity<?> assignCourse(
            @RequestParam Long managerId,
            @RequestParam Long courseId,
            @RequestParam Long employeeId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate deadline) {

        CourseAssignment assignment = managerService.assignCourse(managerId,courseId.intValue(), employeeId, deadline);
        return ResponseEntity.ok(assignment);
    }

    /**
     * Monitor employee progress.
     */
    @GetMapping("/progress/{employeeId}")
    public ResponseEntity<?> monitorProgress(@PathVariable Integer employeeId) {
        Map<String, Object> progress = managerService.monitorEmployeeProgress(employeeId);
        return ResponseEntity.ok(progress);
    }

    /**
     * Get all assignments created by a manager.
     */
    @GetMapping("/assignments/{managerId}")
    public ResponseEntity<?> getAssignments(@PathVariable Long managerId) {
        List<CourseAssignment> assignments = managerService.getAssignmentsByManager(managerId);
        return ResponseEntity.ok(assignments);
    }
}
